// Initialize global vars
const projectData = []; // Empty array used as endpoint for all routes
const port = 3030;

// Include Node.js modules
const express = require( 'express' );
const bodyParser = require( 'body-parser' );
const cors = require( 'cors' );

// Initialize instance of the server using Express
const app = express();

// Setup server
app.use( express.static('website') ); // Specify app directory
app.use( bodyParser.urlencoded({ extended: false }) );
app.use( bodyParser.json() );
app.use( cors() ); 
app.listen( port, portInfo );

// Port info callback
function portInfo(){
	console.log( `Server Running on Port: ${port}` );
}

// Add POST route
app.post( '/upload', postData );
function postData( request, response ){

	projectData.push( request.body );
	console.log( 'postData()' );
	console.log( request.body );
	response.send( request.body );

}

// Add GET route
app.get( '/all', getData );
function getData( request, response ){

	console.log( 'getData()' );
	console.log( projectData );
	response.send( projectData );

}