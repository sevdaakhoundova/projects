# Weather-Journal App Project

## Table of Contents

- [Overview](#overview)
- [Instructions](#instructions)
- [Extras](#extras)

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
This will require modifying the `server.js` file and the `website/app.js` file. You can see `index.html` for element references, and once you are finished with the project steps, you can use `style.css` to style your application to customized perfection.

- Setup Node.js.
- Add the express, body-parser, and cors modules to Node.
- Ran the local server
- Created API credentials on OpenWeatherMap.com
- Store personal API key in a const variable.
- Test if Data is successfully received from the weather API
- Implement GET and POST routes on both the client and the server
- Test if app data is dynamically updated 
- Add event listener to the form button using JS

## Extras
If you are interested in testing your code as you go, you can use `tests.js` as a template for writing and running some basic tests for your code.