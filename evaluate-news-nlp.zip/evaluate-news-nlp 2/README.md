# Evaluate News Article With NLP

This project is a project which showcases a client - server architecture to access the aylien api and show the respons in the browser on any article or url you paste into it

## Run

Run `npm i` to preinstall project

Use following 4 commands

`npm run build-dev` - To start a dev server 
`npm run build-prod` - To create a production build in the dist folder to be served by the server  
`npm run test` - To run jest tests  
`npm run start` - To start the node server  

## Use

Build via `npm run build-prod` and start the server via `npm run start`
Access page via the url `localhost:8080`
Paste in a url to an article you want to analyse and click submit.