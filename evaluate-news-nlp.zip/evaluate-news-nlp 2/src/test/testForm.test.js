import { handleSubmit } from '../client/js/testForm';

global.fetch = require("jest-fetch-mock");

describe('testing submit', () => {
    it('handleSubmit submits data', () => {
        document.body.innerHTML = `<main>
                <section>
                    <form class="" onsubmit="return Client.handleSubmit(event)">
                        <label for="url">Type in a URL to the text you want to analyse</label>
                        <input id="url" type="text" name="input" value="https://www.google.com/" placeholder="URL">
                        <input type="submit" name="" value="submit" onclick="return Client.handleSubmit(event)" onsubmit="return Client.handleSubmit(event)">
                    </form>
                </section>
                <section>
                <h2>See Results</h2>
                <dl>
                    <dt>Polarity</dt>
                    <dd id="polarity"></dd>
                    <dt>Confidence</dt>
                    <dd id="polarity_confidence"></dd>
                    </br>
                    <dt>Subjectivity</dt>
                    <dd id="subjectivity"></dd>
                    <dt>Confidence</dt>
                    <dd id="subjectivity-confidence"></dd>
                    </br>
                    <dt>Text</dt>
                    <dd id="nlp-text"></dd>
                </dl> 
                </section>
            </main>`;

        fetch.mockResponseOnce(JSON.stringify({ text: 'test' }));
        handleSubmit({ preventDefault: () => {} });

        expect(fetch.mock.calls.length).toEqual(1);

    })
})