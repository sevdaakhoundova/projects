import { testURL } from '../client/js/testURL';

describe('testing submit', () => {
    it('Returns true on valid url', () => {
        expect(testURL('https://www.google.com/')).toBe(true);
    })

    it('Returns false on invalid url', () => {
        expect(testURL('nope')).toBe(false);
    })
})