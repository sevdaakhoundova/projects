# Landing Page Project

## Table of Contents

- [Instructions](#instructions)
- [Runtime](#runtime)
- [Usability](#usability)
- [Behavior](#behavior)


## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

To get started, open `js/app.js` and start building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.

## Runtime

Open a new terminal and run `npx http-server -c-1 -o` task in your development folder. The code will launch a no-cache enabled development server and automatically open your default browser. Reload the browser when new changes are applied.

## Usability
	
All features are usable across modern desktop, tablet, and phone browsers.

## Behavior

Navigation is built dynamically as an unordered list based on the page section. Adding a new HTML 'section'  to the page will automatically create a corresponding new navigation list.