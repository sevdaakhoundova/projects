/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
const navPanel = document.querySelectorAll('section')
const navListView = document.getElementById('navbar__list')

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

navPanel.forEach(el => {
    const navListItem = `<li class='menu__link ${el.className}' data-link=${el.id}><a href="#${el.id}">${el.dataset.nav}</li>`
    navListView.insertAdjacentHTML('beforeend', navListItem)
})

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport
const callback = entries => {
    entries.forEach(entry => {
    const navListItem = document.querySelector (
    `.menu__link[data-link='${entry.target.id}']`,
    )
    const section = document.getElementById(entry.target.id)

    if (entry && entry.isIntersecting) {
    navListItem.classList.add('active')
    section.classList.add('active')
    } 
    else {
    if (navListItem.classList.contains('active')) {
        navListItem.classList.remove('active')
    }

    if (section.classList.contains('active')) {
        section.classList.remove('active')
    }
    }
    })
}

// Scroll to anchor ID using scrollTO event

navListView.addEventListener('click', e => {a
    e.preventDefault()
    const parent = e.target.hasAttribute('data-link')
      ? e.target
      : e.target.parentElement
    const elementToScrollTo = document.getElementById(parent.dataset.link)
    elementToScrollTo.scrollIntoView({block: 'end', behavior: 'smooth'})
})

/**
 * End Main Functions
 * Begin Events
 * 
*/
const options = {
    root: null,
    rootMargin: '0px',
    threshold: 0.6,
  }
// support for all modern browser https://caniuse.com/#feat=intersectionobserver
const observer = new IntersectionObserver(callback, options)
navPanel.forEach(el => {
  observer.observe(document.getElementById(el.id))
})

// Build menu 

// Scroll to section on link click

// Set sections as active

